
public interface StudentDuties {

	public void viewCourseBank(Database d);

	public void viewOpenCourses(Database d);

	public void register(Database d);

	public void withdraw(Database d);

	public void viewSchedule();

}
